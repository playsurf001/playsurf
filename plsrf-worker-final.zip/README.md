# Projeto Cloudflare Pages
Upload direto no GitHub e conectar ao Cloudflare Pages.